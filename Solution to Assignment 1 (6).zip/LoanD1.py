#!/usr/bin/env python
# coding: utf-8

# In[1]:


#loading the dataset
import pandas as pd   
df=pd.read_excel("bank-additional-full.xlsx")


# In[2]:


df


# In[3]:


#renaming the column headers of unsupported format
df.rename(columns = {'emp.var.rate':'emp_var_rate', 'cons.price.idx':'cons_price_idx','cons.conf.idx':'cons_conf_idx', 'nr.employed':'nr_employed'}, inplace = True)
df


# In[4]:


#we assign numeric weightage to unique column entries for columns with <=3 unique entries
df['marital'].replace(['married','single','divorced','unknown'],[1,0,2,3], inplace=True)
df['default'].replace(['no','unknown','yes'],[0,2,1], inplace=True)
df['housing'].replace(['no','unknown','yes'],[0,2,1], inplace=True)
df['loan'].replace(['no','unknown','yes'],[0,2,1], inplace=True)
df['contact'].replace(['telephone', 'cellular'],[0, 1], inplace=True)
df['poutcome'].replace(['nonexistent','failure','success'],[2,0,1], inplace=True)
df['y'].replace(['no', 'yes'],[0, 1], inplace=True)
df


# In[5]:


#for non numeric features we perform one hot encoding
df = pd.get_dummies(df, columns = ['job','education','month','day_of_week'])
df


# In[9]:


#Decision Tree Classifier (grid search) to tune the hyperparameters
from sklearn.model_selection import GridSearchCV
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn import datasets

# Split the data into features and target variable
X = df.drop('y', axis=1)
y = df['y']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2, random_state=123)

# Create an instance of decision tree classifier
clf = DecisionTreeClassifier(random_state=123)
# Create grid parameters for hyperparameter tuning

params={'criterion':['gini','entropy','log-loss'],
        'max_depth': range(1,10),
        'min_samples_leaf':range(1,5),
        'min_samples_split':range(1,10),  
       }

# Create gridsearch instance
grid = GridSearchCV(estimator=clf,
                    param_grid=params,
                    cv=10,
                    n_jobs=1,
                    verbose=2)
# Fit the model
grid.fit(X_train, y_train)


# In[6]:


#Decision Tree Classifier
import time
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn.metrics import roc_auc_score
from sklearn.metrics import log_loss
import tracemalloc

# Split the data into features and target variable
X = df.drop('y', axis=1)
y = df['y']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2, random_state=123)

# Train the decision tree classifier

def classify_decision_tree():
    clf = DecisionTreeClassifier(max_depth=5, min_samples_leaf=4, min_samples_split=1,random_state=123)
    clf.fit(X_train, y_train)
    return clf

tracemalloc.start()
start=time.perf_counter()
clf=classify_decision_tree()
end=time.perf_counter()
# Make predictions on the testing data
y_pred = clf.predict(X_test)
print('get_traced_memory(current-peak):',tracemalloc.get_traced_memory())
tracemalloc.stop()

# Evaluate the performance of the model

results = confusion_matrix(y_test, y_pred)
print ('Confusion Matrix :')
print(results)
print ('Accuracy Score is',accuracy_score(y_test, y_pred))
print ('Classification Report : ')
print (classification_report(y_test, y_pred))
print('AUC-ROC:',roc_auc_score(y_test, y_pred))
print('LOGLOSS Value is',log_loss(y_test, y_pred))
print("time taken for DT",(end-start),"seconds")



# In[7]:


#Naive Bayes Classifier
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report
from sklearn.metrics import roc_auc_score
from sklearn.metrics import log_loss


# Split the data into features and target variable
X = df.drop('y', axis=1)
y = df['y']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2, random_state=0)


# Train the Naive Bayes classifier

def method_classify():

    clf = GaussianNB(var_smoothing=2e-9)
    clf.fit(X_train, y_train)
    

tracemalloc.start()
start=time.perf_counter()
method_classify()
end=time.perf_counter()
print('get_traced_memory(current-peak):',tracemalloc.get_traced_memory())
tracemalloc.stop()

# Make predictions on the testing data
y_pred = clf.predict(X_test)


results = confusion_matrix(y_test, y_pred)
print ('Confusion Matrix :')
print(results)
print ('Accuracy Score is',accuracy_score(y_test, y_pred))
print ('Classification Report : ')
print (classification_report(y_test, y_pred))
print('AUC-ROC:',roc_auc_score(y_test, y_pred))
print('LOGLOSS Value is',log_loss(y_test, y_pred))
print("time taken for NB",(end-start),"seconds")




# In[ ]:




