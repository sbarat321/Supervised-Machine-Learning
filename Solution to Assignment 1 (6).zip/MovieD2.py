#!/usr/bin/env python
# coding: utf-8

# In[2]:


#loading the dataset
import pandas as pd
df=pd.read_csv("Data for repository.csv")


# In[3]:


df


# In[4]:


#Creating a Profit Column
df['Profit']=df['Revenue(INR)']-df['Budget(INR)']
df


# In[5]:


#renaming the column headers of unsupported format
df.rename(columns = {'Movie Name':'Movie_Name', 'Release Period':'Release_Period','Whether Remake':'Whether_Remake', 'Whether Franchise':'Whether_Franchise', 'New Actor':'New_Actor', 'New Director':'New_Director', 'New Music Director':'New_Music_Director', 'Lead Star':'Lead_Star', 'Music Director':'Music_Director', 'Number of Screens':'Number_of_Screens'}, inplace = True)
df


# In[6]:


#deleted redundant columns
df.drop(['Movie_Name', 'Revenue(INR)', 'Budget(INR)'], axis = 1, inplace = True)
df


# In[7]:


#make the profit (categorical) column binary
df['Profit'] = df['Profit'].apply(lambda x: 0 if x <= 0 else 1)
df


# In[8]:


#we assign numeric weightage to unique column entries for columns with two unique entries
df['Release_Period'].replace(['Normal', 'Holiday'],[0, 1], inplace=True)
df['Whether_Remake'].replace(['No', 'Yes'],[0, 1], inplace=True)
df['Whether_Franchise'].replace(['No', 'Yes'],[0, 1], inplace=True)
df['New_Actor'].replace(['No', 'Yes'],[0, 1], inplace=True)
df['New_Director'].replace(['No', 'Yes'],[0, 1], inplace=True)
df['New_Music_Director'].replace(['No', 'Yes'],[0, 1], inplace=True)
df


# In[9]:


#for non numeric features we perform one hot encoding
df = pd.get_dummies(df, columns = ['Genre','Music_Director','Lead_Star','Director'])
df


# In[36]:


#Decision Tree Classifier (grid search) to tune the hyperparameters
from sklearn.model_selection import GridSearchCV
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn import datasets

# Split the data into features and target variable
X = df.drop('Profit', axis=1)
y = df['Profit']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2, random_state=123)

# Create an instance of decision tree classifier
clf = DecisionTreeClassifier(random_state=123)
# Create grid parameters for hyperparameter tuning

params={'max_depth': range(1,10),
            'min_samples_leaf':range(1,5),
           'min_samples_split':range(1,10),  
       }

# Create gridsearch instance
grid = GridSearchCV(estimator=clf,
                    param_grid=params,
                    cv=10,
                    n_jobs=-1,
                    verbose=1)
# Fit the model
grid.fit(X_train, y_train)


# In[12]:


#Decision Tree Classifier
import time
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn.metrics import roc_auc_score
from sklearn.metrics import log_loss
import tracemalloc

# Split the data into features and target variable
X = df.drop('Profit', axis=1)
y = df['Profit']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2, random_state=123)

# Train the decision tree classifier
def classify_decision_tree():
    clf = DecisionTreeClassifier(max_depth=5, min_samples_leaf=4, min_samples_split=1,random_state=123)
    clf.fit(X_train, y_train)
    return clf

tracemalloc.start()
start=time.perf_counter()
clf=classify_decision_tree()
end=time.perf_counter()
# Make predictions on the testing data
y_pred = clf.predict(X_test)
print('get_traced_memory(current-peak):',tracemalloc.get_traced_memory())
tracemalloc.stop()


# Evaluate the performance of the model
results = confusion_matrix(y_test, y_pred)
print ('Confusion Matrix :')
print(results)
print ('Accuracy Score is',accuracy_score(y_test, y_pred))
print ('Classification Report : ')
print (classification_report(y_test, y_pred))
print('AUC-ROC:',roc_auc_score(y_test, y_pred))
print('LOGLOSS Value is',log_loss(y_test, y_pred))

print("time taken for DT",(end-start),"seconds")


# In[10]:


#Naive Bayes Classifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn.metrics import roc_auc_score
from sklearn.metrics import log_loss

# Split the data into features and target variable
X = df.drop('Profit', axis=1)
y = df['Profit']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2, random_state=123)


# Train the Naive Bayes classifier


def classify_naive_bayes():    
    clf = MultinomialNB(alpha=0.054)
    clf.fit(X_train, y_train)
    return clf

tracemalloc.start()    
start=time.perf_counter()
clf=classify_naive_bayes()
# Make predictions on the testing data
y_pred = clf.predict(X_test)
print('get_traced_memory(current-peak):',tracemalloc.get_traced_memory())
tracemalloc.stop()
end=time.perf_counter()


# Evaluate the performance of the model

print("time taken for DT",(end-start),"seconds")

results = confusion_matrix(y_test, y_pred)
print ('Confusion Matrix :')
print(results)
print ('Accuracy Score is',accuracy_score(y_test, y_pred))
print ('Classification Report : ')
print (classification_report(y_test, y_pred))
print('AUC-ROC:',roc_auc_score(y_test, y_pred))
print('LOGLOSS Value is',log_loss(y_test, y_pred))




# In[ ]:




